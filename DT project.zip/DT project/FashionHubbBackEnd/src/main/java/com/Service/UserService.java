package com.Service;

import com.Model.User;

public interface UserService {
	 public boolean InsertUser(User user);
	 
	 	

}
