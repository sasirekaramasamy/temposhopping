package com.DAO;

import com.Model.User;

public interface UserDAO {
	public  void show(String email);
	public boolean InsertUser(User user);
}
