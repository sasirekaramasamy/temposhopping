package com.DAOImpl;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.DAO.UserDAO;
import com.DAOImpl.UserDAOImpl;
import com.Model.User;


@Repository(value="UserDAO")
public class UserDAOImpl implements UserDAO {
	public static Logger log=LoggerFactory.getLogger(UserDAOImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	public void UserDaoImpl(SessionFactory sessionFactory){
		this.sessionFactory=sessionFactory;

	}

	public void show(String email) {
	
		
	}

	public boolean InsertUser(User user) {
		   sessionFactory.openSession();  
		  //session.saveOrUpdate(user);

		sessionFactory.getCurrentSession().saveOrUpdate(user);
		return false;
	}
	
		
	}
	


