package com.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.DAO.UserDAO;
import com.Model.User;
import com.Service.UserService;

public class UserServiceImpl implements UserService {
	@Autowired
UserDAO userdao;
	
	public boolean InsertUser(User user) {
		return userdao.InsertUser(user);
		
	}
}